# House Price Prediction (California Housing)

A machine learning project that predicts median house values in California using the
California Housing dataset from scikit-learn.

## Project Overview
The notebook walks through a full ML workflow: loading and exploring data, cleaning it,
visualizing it, splitting it, training three regression models, evaluating them, comparing
them, and saving the best one.

## Dataset
- Source: `sklearn.datasets.fetch_california_housing` (downloaded automatically on first use, internet required)
- About 20,640 rows, 8 input features, 1 target
- Target: `MedHouseVal`, median house value in units of $100,000

| Feature | Meaning |
|---|---|
| MedInc | Median income in the block (in $10,000) |
| HouseAge | Median house age |
| AveRooms | Average rooms per household |
| AveBedrms | Average bedrooms per household |
| Population | Block population |
| AveOccup | Average household members |
| Latitude / Longitude | Location |

## Workflow
1. Load and explore the data
2. EDA and visualization (distributions, correlation heatmap, location map)
3. Cleaning: remove duplicates, remove capped prices (5.0), check missing values
4. Feature engineering: `BedroomRatio`, `RoomsPerPerson`
5. 80/20 train-test split (`random_state=42`)
6. Outlier clipping using percentiles computed on the training set only (avoids data leakage)
7. Train Linear Regression (with StandardScaler), Decision Tree (`max_depth=8`), Random Forest (100 trees)
8. Evaluate with MAE, MSE, RMSE and R2
9. Compare models, select the best by test R2
10. Save the best model with joblib

## Metrics
- **MAE**: average absolute error
- **MSE**: average squared error
- **RMSE**: square root of MSE, same unit as the target
- **R2**: proportion of variance explained (closer to 1 is better)

## Results
Results are not filled in yet. Run the notebook, then paste the table from `results/model_comparison.csv` here.

| Model | MAE | MSE | RMSE | R2 (Test) |
|---|---|---|---|---|
| Linear Regression | - | - | - | - |
| Decision Tree | - | - | - | - |
| Random Forest | - | - | - | - |

## How to Run
Google Colab: upload `House_Price_Prediction.ipynb` to Colab and choose Runtime > Run all.

Locally:
```
pip install -r requirements.txt
jupyter notebook House_Price_Prediction.ipynb
```

## Using the Saved Model
After running the notebook, `models/best_model.joblib` and `models/feature_columns.joblib` are created.
```python
import joblib
model = joblib.load("models/best_model.joblib")
features = joblib.load("models/feature_columns.joblib")
# new_data must be a DataFrame with exactly these columns, including BedroomRatio and RoomsPerPerson
# prediction = model.predict(new_data[features])
```

## Project Structure
```
House-Price-Prediction-ML/
|-- House_Price_Prediction.ipynb
|-- requirements.txt
|-- README.md
|-- models/      (created when the notebook runs)
|-- results/     (created when the notebook runs)
```

## Tools
Python, pandas, NumPy, scikit-learn, matplotlib, seaborn, joblib
